"""Check that text-only models never receive or read image attachments."""
import os
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from core import request


class TextInputTests(unittest.TestCase):
    def test_text_mode_calls_api_without_opening_an_image(self):
        client = Mock()
        answer = '{"ranking":["B","A"]}'
        client.chat.completions.create.return_value = SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=answer), logprobs=None)])
        with patch.dict(os.environ, {"LLM_INPUT_MODE": "text"}), \
             patch.object(request, "_client", return_value=client), \
             patch.object(request, "_backend", return_value="ollama"), \
             patch.object(request, "_model", return_value="llama3.2:3b"), \
             patch.object(request, "encode_image") as encode:
            result, _ = request.send_image_to_model_openai_logprobs(
                "/nonexistent/grid.png", "unchanged grid and distances", temperature=0)
        encode.assert_not_called()
        self.assertEqual(result, answer)
        sent = client.chat.completions.create.call_args.kwargs
        self.assertEqual(sent["messages"], [{"role": "user", "content": "unchanged grid and distances"}])
        self.assertEqual(sent["model"], "llama3.2:3b")

    def test_image_mode_keeps_text_and_image(self):
        with patch.dict(os.environ, {"LLM_INPUT_MODE": "image"}), \
             patch.object(request, "encode_image", return_value="IMAGE"):
            content = request.ranking_content("grid.png", "same prompt")
        self.assertEqual(content, [{"type": "text", "text": "same prompt"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64,IMAGE"}}])

    def test_invalid_mode_cannot_silently_drop_images(self):
        with patch.dict(os.environ, {"LLM_INPUT_MODE": "typo"}):
            with self.assertRaises(ValueError):
                request.ranking_content("grid.png", "prompt")


if __name__ == "__main__":
    unittest.main()
